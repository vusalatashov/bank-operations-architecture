package az.xalqbank.mscustomers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsCustomersApplicationTests {

    @Test
    void contextLoads() {
    }

}
