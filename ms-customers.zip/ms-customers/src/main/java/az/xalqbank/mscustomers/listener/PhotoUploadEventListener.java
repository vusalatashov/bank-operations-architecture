package az.xalqbank.mscustomers.listener;

import az.xalqbank.mscustomers.config.RabbitMQConfig;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class PhotoUploadEventListener {

    @RabbitListener(queues = RabbitMQConfig.PHOTO_UPLOAD_QUEUE)
    public void handlePhotoUploadEvent(String message) {
        // Mesajı alıyoruz ve logluyoruz
        System.out.println("Received message: " + message);

        // Burada mesajı işleyerek ilgili müşteri profilini güncelleyebilirsiniz
        // Mesajdan müşteri ID'si ve fotoğraf URL'sini çıkarabilirsiniz
        // Örneğin:
        String[] messageParts = message.split(", ");
        String customerIdPart = messageParts[0];
        String fileUrlPart = messageParts[1];

        String customerId = customerIdPart.split(": ")[1];  // Müşteri ID'sini alıyoruz
        String fileUrl = fileUrlPart.split(": ")[1];  // Fotoğraf URL'sini alıyoruz

        // Bu bilgileri kullanarak ilgili müşteri profili üzerinde işlem yapabilirsiniz
        System.out.println("Customer ID: " + customerId);
        System.out.println("File URL: " + fileUrl);

        // Bu adımda, müşteri profilini güncelleme işlemleri yapılabilir
    }
}
