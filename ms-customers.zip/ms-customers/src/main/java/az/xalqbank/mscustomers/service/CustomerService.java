package az.xalqbank.mscustomers.service;

import az.xalqbank.mscustomers.dto.CustomerDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Optional;

public interface CustomerService {

    // Tüm müşterileri listele
    List<CustomerDTO> getAllCustomers();

    // ID'ye göre müşteri bilgilerini al
    Optional<CustomerDTO> getCustomerById(Long id);

    // E-posta adresine göre müşteri bilgilerini al
    Optional<CustomerDTO> getCustomerByEmail(String email);

    // Yeni müşteri ekle
    CustomerDTO addCustomer(String name, String email, String phoneNumber, MultipartFile file);

    // Müşteri bilgilerini güncelle
    CustomerDTO updateCustomer(Long id, String name, String email, String phoneNumber, MultipartFile file);
    // Müşteri sil
    boolean deleteCustomer(Long id);

    // Profil fotoğrafını yükle
    CustomerDTO uploadProfilePhoto(Long customerId, MultipartFile photoFile);
}
