package az.xalqbank.mscustomers.controller;

import az.xalqbank.mscustomers.dto.CustomerDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface CustomerController {

    ResponseEntity<List<CustomerDTO>> getAllCustomers();  // Tüm müşterileri listele

    ResponseEntity<CustomerDTO> getCustomerById(Long id);  // ID'ye göre müşteri bilgilerini al

    ResponseEntity<CustomerDTO> getCustomerByEmail(String email);  // E-posta ile müşteri bilgilerini al

    ResponseEntity<CustomerDTO> addCustomer(String name, String email, String phoneNumber, MultipartFile file) throws IOException;  // Yeni müşteri ekle

    ResponseEntity<CustomerDTO> updateCustomer(Long id, String name, String email, String phoneNumber, MultipartFile file) throws IOException;  // Müşteri bilgilerini güncelle

    ResponseEntity<Void>deleteCustomer(Long id);  // Müşteri sil
}
