package az.xalqbank.mscustomers.service;

import az.xalqbank.mscustomers.dto.CustomerDTO;
import az.xalqbank.mscustomers.model.Customer;
import az.xalqbank.mscustomers.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;
    private final RedisTemplate<String, Object> redisTemplate;

    @Override
    public List<CustomerDTO> getAllCustomers() {
        String cacheKey = "customers:all";
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();

        // Redis'te önbelleğe alınmış müşteri listesi var mı?
        List<CustomerDTO> customers = (List<CustomerDTO>) valueOperations.get(cacheKey);
        if (customers != null) {
            return customers;
        }

        // Eğer Redis'te yoksa, veritabanından çek ve cache'e ekle
        customers = customerRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        valueOperations.set(cacheKey, customers, Duration.ofMinutes(10)); // 10 dakika cache'te tut
        return customers;
    }

    @Override
    public Optional<CustomerDTO> getCustomerById(Long id) {
        String cacheKey = "customer:" + id;
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();

        // Redis'te önbelleğe alınmış müşteri var mı?
        CustomerDTO cachedCustomer = (CustomerDTO) valueOperations.get(cacheKey);
        if (cachedCustomer != null) {
            return Optional.of(cachedCustomer);
        }

        // Eğer Redis'te yoksa, veritabanından çek ve cache'e ekle
        Optional<CustomerDTO> customerDTO = customerRepository.findById(id).map(this::convertToDTO);
        customerDTO.ifPresent(dto -> valueOperations.set(cacheKey, dto, Duration.ofMinutes(10)));

        return customerDTO;
    }

    @Override
    public Optional<CustomerDTO> getCustomerByEmail(String email) {
        String cacheKey = "customer:email:" + email;
        ValueOperations<String, Object> valueOperations = redisTemplate.opsForValue();

        // Redis'te önbelleğe alınmış müşteri var mı?
        CustomerDTO cachedCustomer = (CustomerDTO) valueOperations.get(cacheKey);
        if (cachedCustomer != null) {
            return Optional.of(cachedCustomer);
        }

        Optional<CustomerDTO> customerDTO = customerRepository.findByEmail(email).map(this::convertToDTO);
        customerDTO.ifPresent(dto -> valueOperations.set(cacheKey, dto, Duration.ofMinutes(10)));

        return customerDTO;
    }

    @Override
    public CustomerDTO addCustomer(String name, String email, String phoneNumber, MultipartFile file){
        // Yeni müşteri oluşturuluyor
        Customer customer = new Customer();
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhoneNumber(phoneNumber);

        // Profil fotoğrafını yükle
        if (file != null && !file.isEmpty()) {
            // Fotoğrafı dış servise veya uygun bir depolama alanına yükle
            // Burada sadece örnek olması için dosya ismini kaydediyoruz
            customer.setProfilePhotoUrl(file.getOriginalFilename());
        }

        // Müşteri veritabanına kaydediliyor
        Customer savedCustomer = customerRepository.save(customer);
        CustomerDTO savedCustomerDTO = convertToDTO(savedCustomer);

        // Redis'e yeni müşteri ekleniyor
        String cacheKey = "customer:" + savedCustomer.getId();
        redisTemplate.opsForValue().set(cacheKey, savedCustomerDTO, Duration.ofMinutes(10));

        // Müşteri listesi cache'ini temizle
        redisTemplate.delete("customers:all");

        return savedCustomerDTO;
    }

    @Override
    public CustomerDTO updateCustomer(Long id, String name, String email, String phoneNumber, MultipartFile file) {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if (optionalCustomer.isEmpty()) {
            return null;
        }

        // Mevcut müşteri bilgileri alınıyor
        Customer customer = optionalCustomer.get();

        // Müşteri detaylarını güncelle
        customer.setName(name);
        customer.setEmail(email);
        customer.setPhoneNumber(phoneNumber);

        // Profil fotoğrafını güncelle
        if (file != null && !file.isEmpty()) {
            customer.setProfilePhotoUrl(file.getOriginalFilename());
        }

        // Güncellenmiş müşteri kaydediliyor
        Customer updatedCustomer = customerRepository.save(customer);
        CustomerDTO updatedCustomerDTO = convertToDTO(updatedCustomer);

        // Redis'teki cache'i güncelle
        String cacheKey = "customer:" + id;
        redisTemplate.opsForValue().set(cacheKey, updatedCustomerDTO, Duration.ofMinutes(10));

        // Müşteri listesi cache'ini temizle
        redisTemplate.delete("customers:all");

        return updatedCustomerDTO;
    }


    @Override
    public boolean deleteCustomer(Long id) {
        if (customerRepository.existsById(id)) {
            customerRepository.deleteById(id);

            // Redis cache temizleme işlemi
            redisTemplate.delete("customer:" + id);
            redisTemplate.delete("customers:all");

            return true;
        }
        return false;
    }

    // Profil fotoğrafı yüklemek yerine dış servise entegre et
    @Override
    public CustomerDTO uploadProfilePhoto(Long customerId, MultipartFile photoFile)  {
        Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
        if (optionalCustomer.isEmpty()) {
            return null;
        }

        Customer customer = optionalCustomer.get();

        // Fotoğrafı dış servise yükleyebilirsiniz (örn. bir dosya depolama servisine).
        // Bu örnekte sadece dosyanın adını kaydediyoruz.
        if (photoFile != null && !photoFile.isEmpty()) {
            customer.setProfilePhotoUrl(photoFile.getOriginalFilename());
        }

        // Güncellenmiş müşteri kaydediliyor
        Customer updatedCustomer = customerRepository.save(customer);
        CustomerDTO updatedCustomerDTO = convertToDTO(updatedCustomer);

        // Redis'e güncellenmiş müşteri bilgileri ekleniyor
        String cacheKey = "customer:" + customerId;
        redisTemplate.opsForValue().set(cacheKey, updatedCustomerDTO, Duration.ofMinutes(10));

        return updatedCustomerDTO;
    }


    private CustomerDTO convertToDTO(Customer customer) {
        return new CustomerDTO(
                customer.getId(),
                customer.getName(),
                customer.getEmail(),
                customer.getPhoneNumber(),
                customer.getProfilePhotoUrl()  // Profil fotoğrafı da ekleniyor
        );
    }
}
