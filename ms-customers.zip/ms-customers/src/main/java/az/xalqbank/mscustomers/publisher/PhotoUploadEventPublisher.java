package az.xalqbank.mscustomers.publisher;

import az.xalqbank.mscustomers.config.RabbitMQConfig;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
public class PhotoUploadEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    public PhotoUploadEventPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void publishPhotoUploadEvent(Long customerId, String fileUrl) {
        // Mesajı oluşturuyoruz
        String message = "Photo uploaded for customer ID: " + customerId + ", File URL: " + fileUrl;

        // RabbitMQ'ya mesaj gönderiyoruz
        rabbitTemplate.convertAndSend(RabbitMQConfig.PHOTO_UPLOAD_QUEUE, message);
    }
}
